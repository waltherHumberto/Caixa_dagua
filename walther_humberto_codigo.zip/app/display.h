void put_mensage(char string_to_print); 
