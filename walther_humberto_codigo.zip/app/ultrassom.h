void init_ultrassom(void);

uint16_t get_distancia_ult();