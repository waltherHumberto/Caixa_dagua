//Input Capture Interrupt
//=======================
#include <Wire.h>
volatile unsigned int previous_capture = 0;
volatile unsigned int current_capture = 0;
long dist = 0;
//============================================================================
void setup()
{
    Serial.begin(9600);
    pinMode(2, OUTPUT);
    Serial.println(F("SSD1306 allocation failed"));

    //programming timer1 for input capture interrupt
    noInterrupts();
    TCCR1A = 0; //initialize timer1 mode
    TCCR1B = 0;
    TCCR1B |= 0b11000101; //set 1024 prescaler, rising edge, noise canceler
    TIMSK1 |= 0b00100000; //enable input capture interrupt
    TCNT1 = 0;            //initialize timer/counter1 register
    interrupts();
}
//============================================================================
ISR(TIMER1_CAPT_vect) //input capture interrupt ISR
{
    static long temp = 0;

    if (TCCR1B & _BV(ICES1))
        temp = ICR1;
    else
        dist = ((ICR1 - temp) * 1e6) / F_CPU / 58;
    TCCR1B ^= _BV(ICES1);
}
//============================================================================
void loop()
{
    digitalWrite(2, HIGH);
    _delay_ms(10);
    digitalWrite(2, LOW);

    Serial.print(dist);
    Serial.println("cm");
}