#include <stdbool.h>

void init_bluetooth(void);
bool verifica_bluetooth();
void get_message_bt(char string);